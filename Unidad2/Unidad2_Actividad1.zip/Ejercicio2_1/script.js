// Ejercicio 2.1
console.log('Ejercicio 2.1 cargado correctamente');
