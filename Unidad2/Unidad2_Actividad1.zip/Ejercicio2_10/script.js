// Ejercicio 2.10
console.log('Ejercicio 2.10 cargado correctamente');
