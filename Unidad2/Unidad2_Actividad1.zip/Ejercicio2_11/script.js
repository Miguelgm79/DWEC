// Ejercicio 2.11
console.log('Ejercicio 2.11 cargado correctamente');
