// Ejercicio 2.12
console.log('Ejercicio 2.12 cargado correctamente');
