// Ejercicio 2.13
console.log('Ejercicio 2.13 cargado correctamente');
