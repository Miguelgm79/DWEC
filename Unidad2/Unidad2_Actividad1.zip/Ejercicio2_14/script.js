// Ejercicio 2.14
console.log('Ejercicio 2.14 cargado correctamente');
