// Ejercicio 2.15
console.log('Ejercicio 2.15 cargado correctamente');
