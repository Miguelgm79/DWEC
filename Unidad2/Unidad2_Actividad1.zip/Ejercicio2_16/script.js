// Ejercicio 2.16
console.log('Ejercicio 2.16 cargado correctamente');
