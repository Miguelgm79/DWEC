// Ejercicio 2.17
console.log('Ejercicio 2.17 cargado correctamente');
