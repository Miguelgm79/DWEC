// Ejercicio 2.18
console.log('Ejercicio 2.18 cargado correctamente');
