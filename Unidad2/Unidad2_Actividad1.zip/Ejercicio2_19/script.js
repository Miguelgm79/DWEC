// Ejercicio 2.19
console.log('Ejercicio 2.19 cargado correctamente');
