// Ejercicio 2.2
console.log('Ejercicio 2.2 cargado correctamente');
