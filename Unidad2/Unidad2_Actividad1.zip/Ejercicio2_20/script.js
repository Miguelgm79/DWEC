// Ejercicio 2.20
console.log('Ejercicio 2.20 cargado correctamente');
