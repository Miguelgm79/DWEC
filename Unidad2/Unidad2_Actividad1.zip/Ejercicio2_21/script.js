// Ejercicio 2.21
console.log('Ejercicio 2.21 cargado correctamente');
