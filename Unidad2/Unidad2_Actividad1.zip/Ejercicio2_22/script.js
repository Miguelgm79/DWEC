// Ejercicio 2.22
console.log('Ejercicio 2.22 cargado correctamente');
