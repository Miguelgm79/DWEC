// Ejercicio 2.23
console.log('Ejercicio 2.23 cargado correctamente');
