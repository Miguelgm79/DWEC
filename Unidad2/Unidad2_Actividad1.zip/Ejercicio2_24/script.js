// Ejercicio 2.24
console.log('Ejercicio 2.24 cargado correctamente');
