// Ejercicio 2.25
console.log('Ejercicio 2.25 cargado correctamente');
