// Ejercicio 2.26
console.log('Ejercicio 2.26 cargado correctamente');
