// Ejercicio 2.27
console.log('Ejercicio 2.27 cargado correctamente');
