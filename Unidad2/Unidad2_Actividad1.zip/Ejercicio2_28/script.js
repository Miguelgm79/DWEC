// Ejercicio 2.28
console.log('Ejercicio 2.28 cargado correctamente');
