// Ejercicio 2.29
console.log('Ejercicio 2.29 cargado correctamente');
