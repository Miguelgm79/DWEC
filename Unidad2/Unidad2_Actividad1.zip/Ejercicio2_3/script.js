// Ejercicio 2.3
console.log('Ejercicio 2.3 cargado correctamente');
