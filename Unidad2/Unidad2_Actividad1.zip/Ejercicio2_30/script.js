// Ejercicio 2.30
console.log('Ejercicio 2.30 cargado correctamente');
