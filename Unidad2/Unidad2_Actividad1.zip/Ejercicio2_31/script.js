// Ejercicio 2.31
console.log('Ejercicio 2.31 cargado correctamente');
