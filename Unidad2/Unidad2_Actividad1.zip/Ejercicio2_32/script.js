// Ejercicio 2.32
console.log('Ejercicio 2.32 cargado correctamente');
