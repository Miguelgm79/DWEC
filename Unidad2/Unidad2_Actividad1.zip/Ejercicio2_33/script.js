// Ejercicio 2.33
console.log('Ejercicio 2.33 cargado correctamente');
