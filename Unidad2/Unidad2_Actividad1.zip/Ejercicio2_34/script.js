// Ejercicio 2.34
console.log('Ejercicio 2.34 cargado correctamente');
