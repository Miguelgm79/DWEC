// Ejercicio 2.35
console.log('Ejercicio 2.35 cargado correctamente');
