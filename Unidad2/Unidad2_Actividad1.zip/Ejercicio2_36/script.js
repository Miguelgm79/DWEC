// Ejercicio 2.36
console.log('Ejercicio 2.36 cargado correctamente');
