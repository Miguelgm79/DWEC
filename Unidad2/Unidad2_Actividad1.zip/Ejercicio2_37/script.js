// Ejercicio 2.37
console.log('Ejercicio 2.37 cargado correctamente');
