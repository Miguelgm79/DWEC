// Ejercicio 2.38
console.log('Ejercicio 2.38 cargado correctamente');
