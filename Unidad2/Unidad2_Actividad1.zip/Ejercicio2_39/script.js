// Ejercicio 2.39
console.log('Ejercicio 2.39 cargado correctamente');
