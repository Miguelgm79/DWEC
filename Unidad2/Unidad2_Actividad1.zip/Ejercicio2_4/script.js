// Ejercicio 2.4
console.log('Ejercicio 2.4 cargado correctamente');
