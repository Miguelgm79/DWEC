// Ejercicio 2.40
console.log('Ejercicio 2.40 cargado correctamente');
