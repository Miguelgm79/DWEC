// Ejercicio 2.41
console.log('Ejercicio 2.41 cargado correctamente');
