// Ejercicio 2.42
console.log('Ejercicio 2.42 cargado correctamente');
