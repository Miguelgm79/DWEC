// Ejercicio 2.43
console.log('Ejercicio 2.43 cargado correctamente');
