// Ejercicio 2.44
console.log('Ejercicio 2.44 cargado correctamente');
