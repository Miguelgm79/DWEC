// Ejercicio 2.45
console.log('Ejercicio 2.45 cargado correctamente');
