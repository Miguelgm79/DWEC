// Ejercicio 2.46
console.log('Ejercicio 2.46 cargado correctamente');
