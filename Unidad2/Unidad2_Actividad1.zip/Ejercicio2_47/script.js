// Ejercicio 2.47
console.log('Ejercicio 2.47 cargado correctamente');
