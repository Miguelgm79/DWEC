// Ejercicio 2.48
console.log('Ejercicio 2.48 cargado correctamente');
