// Ejercicio 2.49
console.log('Ejercicio 2.49 cargado correctamente');
