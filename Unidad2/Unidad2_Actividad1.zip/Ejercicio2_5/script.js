// Ejercicio 2.5
console.log('Ejercicio 2.5 cargado correctamente');
