// Ejercicio 2.50
console.log('Ejercicio 2.50 cargado correctamente');
