// Ejercicio 2.51
console.log('Ejercicio 2.51 cargado correctamente');
