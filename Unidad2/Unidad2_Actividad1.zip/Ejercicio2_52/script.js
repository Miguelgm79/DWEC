// Ejercicio 2.52
console.log('Ejercicio 2.52 cargado correctamente');
