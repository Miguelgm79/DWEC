// Ejercicio 2.53
console.log('Ejercicio 2.53 cargado correctamente');
