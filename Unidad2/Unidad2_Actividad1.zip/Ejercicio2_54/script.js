// Ejercicio 2.54
console.log('Ejercicio 2.54 cargado correctamente');
