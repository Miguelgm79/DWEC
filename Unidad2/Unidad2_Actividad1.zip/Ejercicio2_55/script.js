// Ejercicio 2.55
console.log('Ejercicio 2.55 cargado correctamente');
