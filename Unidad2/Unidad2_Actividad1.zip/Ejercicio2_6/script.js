// Ejercicio 2.6
console.log('Ejercicio 2.6 cargado correctamente');
