// Ejercicio 2.7
console.log('Ejercicio 2.7 cargado correctamente');
