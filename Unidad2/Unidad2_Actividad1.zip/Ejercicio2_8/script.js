// Ejercicio 2.8
console.log('Ejercicio 2.8 cargado correctamente');
