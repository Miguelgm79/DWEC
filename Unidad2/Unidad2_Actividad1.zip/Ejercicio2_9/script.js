// Ejercicio 2.9
console.log('Ejercicio 2.9 cargado correctamente');
